package com.shalem.userprofileservice.controller;

import com.shalem.userprofileservice.config.CustomUserDetailsService;
import com.shalem.userprofileservice.dto.LoginRequest;
import com.shalem.userprofileservice.dto.LoginResponse;
import com.shalem.userprofileservice.dto.UserProfileDto;
import com.shalem.userprofileservice.dto.ValidityResponse;
import com.shalem.userprofileservice.entity.UserProfile;
import com.shalem.userprofileservice.exception.UserAlreadyExistsException;
import com.shalem.userprofileservice.jwtUtil.JwtUtil;
import com.shalem.userprofileservice.service.UserProfileService;

import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/v1.0/user")
@Slf4j
public class UserController {

    @Autowired
    private UserProfileService userProfileService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/register")
    public ResponseEntity<UserProfile> register(@Valid @RequestBody UserProfileDto userProfileDto) throws Exception {
        try{
            return new ResponseEntity<>(userProfileService.register(userProfileDto), HttpStatus.CREATED);
        }catch (UserAlreadyExistsException e){
            log.info(e.getMessage());
            throw  new UserAlreadyExistsException(e.getMessage());
        }

    }

    @GetMapping("/{id}")
    public ResponseEntity<UserProfile> getUser(@PathVariable("id")Long id) throws Exception {
        try{
            return new ResponseEntity<>(userProfileService.getUserById(id),HttpStatus.OK);
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }



    @GetMapping("/all")
    public ResponseEntity<List<UserProfile>> getAllUsers() throws Exception {
        try{
            return new ResponseEntity<>(userProfileService.getAllUsers(),HttpStatus.OK);
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }

    @GetMapping("/validate")
    public ValidityResponse validate(@RequestParam("token") String token) throws Exception {
        try{
            String userName=jwtUtil.extractUsername(token);
            UserDetails userDetails = customUserDetailsService.loadUserByUsername(userName);
            ValidityResponse response=new ValidityResponse();
            if(jwtUtil.validateToken(token,userDetails)){
                response.setIsValid(true);
                return response;
            }else{
                response.setIsValid(false);
                return response;
            }

        }catch (Exception e){
            throw new Exception(e.getMessage());
        }
    }

    @PutMapping("/update")
    public ResponseEntity<UserProfile> updateUser(@RequestBody UserProfileDto userProfileDto,@RequestParam("id") Long id) throws Exception {
        try{
            return new ResponseEntity<>(userProfileService.updateUser(userProfileDto,id),HttpStatus.OK);
        }catch (Exception e){
            throw new Exception(e.getMessage());
        }

    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> generateToken(@RequestBody LoginRequest authRequest) throws Exception{
        try{
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(authRequest.getEmail(),authRequest.getPassword()
                    ));
        }
        catch (Exception e) {
            throw  new Exception("Invalid username/password");
        }
        LoginResponse response=new LoginResponse();
        response.setToken(jwtUtil.generateToken(authRequest.getEmail()));
        response.setMessage("User Logged in Successfully");
        return new ResponseEntity<>(response,HttpStatus.OK);

    }


}
