package com.shalem.movieservice.service;

import com.shalem.movieservice.entity.Movie;

import java.util.List;

public interface MovieService {
    public List<Movie> getALlMovies() throws Exception;

    public Movie getMovieByRank(long rank) throws Exception;
}
