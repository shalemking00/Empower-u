package com.shalem.apigateway.filter;
import com.shalem.apigateway.ValidityResponse;
import org.reactivestreams.Publisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferFactory;
import org.springframework.http.*;
import org.springframework.http.server.RequestPath;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.function.Supplier;

@Configuration
public class CustomFilter implements GlobalFilter{
    @Autowired
    private RestTemplate restTemplate;
    Logger logger= LoggerFactory.getLogger(CustomFilter.class);

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        RequestPath path=request.getPath();
//        path.contextPath().value()
        if(path.toString().equals("/api/v1.0/user/login") || path.toString().equals("/api/v1.0/user/register") ){
            return chain.filter(exchange).then(Mono.fromRunnable(() -> {
                ServerHttpResponse response = exchange.getResponse();
                logger.info(response.getStatusCode().toString());
            }));
        }else{
            logger.info(path.toString());
            logger.info("Authorization = " + request.getHeaders().get("Authorization"));
            String[] token = request.getHeaders().get("Authorization").get(0).split(" ");
            logger.info(token[1]);

            ResponseEntity<ValidityResponse> validityResponseResponseEntity = restTemplate.exchange("http://localhost:8081/api/v1.0/user/validate?token=" + token[1], HttpMethod.GET, null, ValidityResponse.class);
            if (validityResponseResponseEntity.getBody().getIsValid()) {
                return chain.filter(exchange).then(Mono.fromRunnable(() -> {
                    ServerHttpResponse response = exchange.getResponse();
                    logger.info(response.getStatusCode().toString());
                }));
            }else{
                return chain.filter(exchange).then(Mono.error(()->new Throwable("Invalid Token")));

            }
        }


    }
}
