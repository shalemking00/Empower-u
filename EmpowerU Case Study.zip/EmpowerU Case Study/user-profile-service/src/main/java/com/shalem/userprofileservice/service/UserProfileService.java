package com.shalem.userprofileservice.service;

import com.shalem.userprofileservice.dto.UserProfileDto;
import com.shalem.userprofileservice.entity.UserProfile;

import java.util.List;

public interface UserProfileService {
    public UserProfile register(UserProfileDto userProfileDto);
    public List<UserProfile> getAllUsers();

    public UserProfile getUserById(Long id) throws Exception;

    public UserProfile updateUser(UserProfileDto userProfileDto,Long id);
}
