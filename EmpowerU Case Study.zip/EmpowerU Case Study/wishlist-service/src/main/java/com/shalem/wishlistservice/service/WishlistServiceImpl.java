package com.shalem.wishlistservice.service;

import com.shalem.wishlistservice.dto.UserResponse;
import com.shalem.wishlistservice.dto.WishListRequest;
import com.shalem.wishlistservice.exception.MovieAlreadyExists;
import com.shalem.wishlistservice.dto.Movie;
import com.shalem.wishlistservice.model.UserWishList;
import com.shalem.wishlistservice.repository.WishlistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class WishlistServiceImpl implements WishlistService {
    @Autowired
    private WishlistRepository wishlistRepository;
    @Autowired
    private RestTemplate restTemplate;

    @Override
    public UserWishList saveFavouriteMovies(String token, Long id, WishListRequest wishListRequest) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);
        HttpEntity<String> entity = new HttpEntity<>(headers);

        UserResponse user = restTemplate.exchange("http://localhost:8081/api/v1.0/user/" + id, HttpMethod.GET, entity, UserResponse.class).getBody();

        if (wishlistRepository.existsByUserId(user.getId())) {
            UserWishList userWishList = wishlistRepository.findByUserId(user.getId()).get();
            userWishList.getMovies().forEach(movie -> {
                if (movie.getRank() != wishListRequest.getMovie().getRank()) {
                    userWishList.getMovies().add(wishListRequest.getMovie());
                } else {
                    throw new MovieAlreadyExists("Movie Already Exists");
                }
            });
            return wishlistRepository.save(userWishList);
        } else {
            UserWishList newWishList = new UserWishList();
            newWishList.setUserId(user.getId());
            List<Movie> movieList = new ArrayList<>();
            movieList.add(wishListRequest.getMovie());
            newWishList.setMovies(movieList);
            return wishlistRepository.save(newWishList);
        }

    }

    @Override
    public List<Movie> getAllMovies(Long id) {
        return null;
    }

//    @Override
//    public List<Movie> getAllMovies(Long id) {
//        if(id!=null){
//
//        }
//        return wishlistRepository.findAll();
//    }

    @Override
    public String deleteMovieFromMoviesList(String id) {
        wishlistRepository.deleteById(id);
        return "Movie Deleted Successfully";
    }

    @Override
    public UserWishList updateUserWishlist(String token, Long id, WishListRequest wishListRequest) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);
        HttpEntity<String> entity = new HttpEntity<>(headers);

        UserResponse user = restTemplate.exchange("http://localhost:8081/api/v1.0/user/" + id, HttpMethod.GET, entity, UserResponse.class).getBody();
        UserWishList userWishList = wishlistRepository.findByUserId(user.getId()).get();
        userWishList.getMovies().forEach(movie -> {
            if (movie.getRank() != wishListRequest.getMovie().getRank()) {
                 userWishList.getMovies().add(wishListRequest.getMovie());
            } else {
                throw new MovieAlreadyExists("Movie Already Exists");
            }
        });
        return wishlistRepository.save(userWishList);
        }
}
