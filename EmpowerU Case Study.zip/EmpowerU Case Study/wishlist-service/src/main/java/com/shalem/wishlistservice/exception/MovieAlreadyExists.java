package com.shalem.wishlistservice.exception;

public class MovieAlreadyExists extends RuntimeException{
    public MovieAlreadyExists(String message) {
        super(message);
    }
}
