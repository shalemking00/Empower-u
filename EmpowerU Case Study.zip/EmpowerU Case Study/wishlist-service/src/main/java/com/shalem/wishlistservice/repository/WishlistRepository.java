package com.shalem.wishlistservice.repository;

import com.shalem.wishlistservice.dto.Movie;
import com.shalem.wishlistservice.model.UserWishList;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface WishlistRepository extends MongoRepository<UserWishList,String> {
    //Boolean existsByRank(Long rank);
    Optional<UserWishList> findByUserId(Long id);
    Boolean existsByUserId(Long id);
}
