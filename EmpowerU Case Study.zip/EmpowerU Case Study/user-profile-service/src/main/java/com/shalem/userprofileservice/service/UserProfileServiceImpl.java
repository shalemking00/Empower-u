package com.shalem.userprofileservice.service;

import com.shalem.userprofileservice.dto.UserProfileDto;
import com.shalem.userprofileservice.entity.UserProfile;
import com.shalem.userprofileservice.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.shalem.userprofileservice.exception.UserAlreadyExistsException;

import java.util.List;

@Service
@Slf4j
public class UserProfileServiceImpl implements UserProfileService{

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public UserProfile register(UserProfileDto userProfileDto) {

        if(!userRepository.existsByEmail(userProfileDto.getEmail())){
            UserProfile newUser=new UserProfile();
            newUser.setEmail(userProfileDto.getEmail());
            newUser.setPassword(passwordEncoder.encode(userProfileDto.getPassword()));
            newUser.setFirstName(userProfileDto.getFirstName());
            newUser.setLastName(userProfileDto.getLastName());
            newUser.setMobile(userProfileDto.getMobile());
            return userRepository.save(newUser);
        }else {
            throw  new UserAlreadyExistsException("user exists with email: "+userProfileDto.getEmail());
        }

    }

    @Override
    public List<UserProfile> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public UserProfile getUserById(Long id) throws Exception {
        if(userRepository.existsById(id)){
            return userRepository.findById(id).get();
        }else {
            throw new Exception("User Not Found with id:" + id);
        }
    }

    @Override
    public UserProfile updateUser(UserProfileDto userProfileDto,Long id) {
        UserProfile existingUser=userRepository.findById(id).orElseThrow(()->new UsernameNotFoundException("User not found with id: "+id));
        existingUser.setEmail(userProfileDto.getEmail());
        existingUser.setMobile(userProfileDto.getMobile());
        existingUser.setPassword(userProfileDto.getPassword());
        existingUser.setFirstName(userProfileDto.getFirstName());
        existingUser.setLastName(userProfileDto.getLastName());
        return userRepository.save(existingUser);
    }
}
