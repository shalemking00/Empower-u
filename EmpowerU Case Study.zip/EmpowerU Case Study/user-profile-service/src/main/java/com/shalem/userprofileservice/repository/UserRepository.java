package com.shalem.userprofileservice.repository;

import com.shalem.userprofileservice.entity.UserProfile;
import org.apache.catalina.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<UserProfile,Long> {
    Boolean existsByEmail(String email);
    UserProfile findByEmailAndPassword(String email,String password);

    UserProfile findByEmail(String email);
}
