package com.shalem.movieservice.controller;

import com.shalem.movieservice.entity.Movie;
import com.shalem.movieservice.service.MovieService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/v1/movies")
@Slf4j
public class MovieController {
    @Autowired
    private MovieService movieService;

    @GetMapping("/all")
    public List<Movie> getAllMovies() throws Exception {
        return movieService.getALlMovies();
    }

    @GetMapping
    public Movie getMovieByRank(@RequestParam("rank") long rank) throws Exception {
        return movieService.getMovieByRank(rank);
    }

//    public Object searchMovieByTitle()







}
