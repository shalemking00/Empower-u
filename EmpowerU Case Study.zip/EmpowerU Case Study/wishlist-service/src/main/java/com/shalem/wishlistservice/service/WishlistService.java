package com.shalem.wishlistservice.service;

import com.shalem.wishlistservice.dto.Movie;
import com.shalem.wishlistservice.dto.WishListRequest;
import com.shalem.wishlistservice.model.UserWishList;

import java.util.List;

public interface WishlistService {

    public UserWishList saveFavouriteMovies(String token,Long id, WishListRequest wishListRequest);

    public List<Movie> getAllMovies(Long id);

    public String deleteMovieFromMoviesList(String id);

    public UserWishList updateUserWishlist(String token, Long id, WishListRequest wishListRequest) throws Exception;

}
