package com.shalem.wishlistservice.controller;

import com.shalem.wishlistservice.dto.Movie;
import com.shalem.wishlistservice.dto.WishListRequest;
import com.shalem.wishlistservice.model.UserWishList;
import com.shalem.wishlistservice.service.WishlistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/wishlist")
public class WishlistController {
    @Autowired
    private WishlistService wishlistService;

    @PostMapping("/{userId}/add")
    public ResponseEntity<UserWishList> saveMovie(@RequestHeader("token")String token,@PathVariable("userId") Long id, @RequestBody WishListRequest wishListRequest){
        return new ResponseEntity<>(wishlistService.saveFavouriteMovies(token,id,wishListRequest), HttpStatus.OK);
    }

    @GetMapping("/{id}/all")
    public ResponseEntity<List<Movie>> getAllMovies(@PathVariable("id") Long id){
        return new ResponseEntity<>(wishlistService.getAllMovies(id),HttpStatus.OK);
    }

    @PutMapping("/{userId}/update")
    public ResponseEntity<UserWishList> updateWishList(@RequestHeader("token")String token,@PathVariable("userId") Long id, @RequestBody WishListRequest wishListRequest ) throws Exception {
        return new ResponseEntity<>(wishlistService.updateUserWishlist(token, id, wishListRequest),HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteMovie(@PathVariable("id") String id){
        return new ResponseEntity<>(wishlistService.deleteMovieFromMoviesList(id),HttpStatus.OK);
    }


}
