package com.shalem.userprofileservice.dto;

import javax.persistence.*;
import javax.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserProfileDto {
    @NotNull(message = "firstname is required")
    @NotBlank
    private String firstName;

    @NotNull(message = "lastname is required")
    @NotBlank
    private String lastName;
    @NotNull(message = "email is required")
    @Email
    private String email;
    @NotNull(message = "password is required")
    @NotBlank
    private String password;
    @NotNull(message = "mobile number is required")
    private Long mobile;
}
